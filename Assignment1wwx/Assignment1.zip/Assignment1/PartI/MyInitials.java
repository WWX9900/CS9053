
public class MyInitials {

	public static void main(String[] args) {
		System.out.println(
				  "W   W  X   X  W   W\n"
				+ "W   W  X   X  W   W\n"
				+ "W   W   X X   W   W\n"
				+ "W W W    X    W W W\n"
				+ "WW WW   X X   WW WW\n"
				+ "WW WW  X   X  WW WW\n"
				+ "W   W  X   X  W   W\n"
				+ "");
	}
}
